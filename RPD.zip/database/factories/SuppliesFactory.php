<?php

use Faker\Generator as Faker;

$factory->define(App\Supplies::class, function (Faker $faker) {
    return [
        //
    ];
});
