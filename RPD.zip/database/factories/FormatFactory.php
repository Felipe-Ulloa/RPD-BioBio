<?php

use Faker\Generator as Faker;

$factory->define(App\Format::class, function (Faker $faker) {
    return [
        //
    ];
});
