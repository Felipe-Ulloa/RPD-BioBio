<?php

use Faker\Generator as Faker;

$factory->define(App\TrayIn_TrayOut::class, function (Faker $faker) {
    return [
        //
    ];
});
