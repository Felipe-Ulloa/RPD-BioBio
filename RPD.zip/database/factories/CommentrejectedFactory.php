<?php

use Faker\Generator as Faker;

$factory->define(App\commentrejected::class, function (Faker $faker) {
    return [
        //
    ];
});
