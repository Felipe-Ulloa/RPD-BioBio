<?php

use Faker\Generator as Faker;

$factory->define(App\motivorejected::class, function (Faker $faker) {
    return [
        //
    ];
});
