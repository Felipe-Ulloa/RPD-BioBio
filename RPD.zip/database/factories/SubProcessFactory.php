<?php

use Faker\Generator as Faker;

$factory->define(App\SubProcess::class, function (Faker $faker) {
    return [
        //
    ];
});
