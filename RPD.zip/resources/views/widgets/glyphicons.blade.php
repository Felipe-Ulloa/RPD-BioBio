<span class="glyphicon glyphicon-{{$class}}" aria-hidden="true"></span>

