<div class="card text-left">
    <div class="card-body">
        <div class="row">
            <div class="form-group col-md-4">
                <?php echo e(Form::label('tarja_proceso', 'Numero de tarja')); ?>

                <?php echo e(Form::text('tarja_proceso','Proceso - '.$lastid, ['class' => 'form-control', 'readonly'])); ?>

            </div>
            <div class="form-group col-md-4">
                <?php echo e(Form::label('wash', 'Lavado')); ?>

                <?php echo e(Form::select('wash', array('Lavado' => 'Si', 'No lavado' => 'No'), 
							null ,['class' => 'form-control','required' ,'placeholder'=>'¿Esta Lavado?'])); ?>

            </div>
        </div>

        <div class="col-md-12">

            <h3 class="text-center">Lista de Recepciones pendientes</h3>

            <h3 class="text-center">Lista de Recepciones</h3>

            <div class=" col-md-4">
            <p>Filtrar:</p>  
            <input class="form-control" id="myInput" type="text" placeholder="Buscar..">
            <br>
            </div>

            <div class="form-group"> 

                <table class="table table-bordered">
                    <thead>
                        <tr class="">
                            <th>N°</th>
                            <th>Especie</th>
                            <th>Variedad</th>
                            <th>Calidad</th>
                            <th>Condición</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__empty_1 = true; $__currentLoopData = $processPending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>  
                            <td><?php echo e($pending->tarja_proceso); ?></td>
                            <td><?php echo e($pending->fruit->specie); ?></td>
                            <td><?php echo e($pending->varieties->variety); ?></td>
                            <td><?php echo e($pending->quality->name); ?></td>
                            <td><?php echo e($pending->status->name); ?></td>
                            <td> <a class="btn btn-sm btn-primary" href=" 
                            <?php echo e(Route('subprocess.create', $pending->id)); ?> "> Reanudar </a> </td>
                            <?php
                            $uno = false;
                            ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h4> Sin Registros </h4>
                        <?php
                        $uno = true;
                        ?>
                        <?php endif; ?>
                    </tbody>
					<div class="float-left">
                    <?php echo e($processPending->render()); ?>

                </div>
                </table> 
        
                <div>
                <table class="table table-bordered">
                    <thead>
                        <tr class="">
                            <th></th>
                            <th>Tarja</th>
                            <th>Fruta</th>
                            <th>Peso Neto</th>
                            <th>Rejillas</th>
                            <th>Calidad</th>
                            <th>Condición</th>
                        </tr>
                    </thead>

                    </br>
                    </br>

                    <tbody id="myTable"> 
                        <?php $__empty_1 = true; $__currentLoopData = $receptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reception): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(Form::checkbox('receptions[]', $reception->id )); ?></td> 
                            <td><?php echo e($reception->tarja); ?></td>
                            <td><?php echo e($reception->fruit->specie); ?> - <?php echo e($reception->varieties->variety); ?></td>
                            <td><?php echo e($reception->netweight); ?></td>
                            <td><?php echo e($reception->quantity); ?></td>
                            <td><?php echo e($reception->quality->name); ?></td>
                            <td><?php echo e($reception->status->name); ?></td>

                            <?php
                            $uno = false;
                            ?>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h4> Sin Registros </h4>
                        <?php
                        $uno = true;
                        ?>
                        <?php endif; ?>
                    </tbody>
					<div class="float-left">
                    <?php echo e($receptions->render()); ?>

                </table>
                </div>
                
            </div>
            <script>
                $(document).ready(function(){
                    $("#myInput").on("keyup", function() {
                        var value = $(this).val().toLowerCase();
                        $("#myTable tr").filter(function() {
                            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                            });
                    });
                });
            </script>
        </div>
    </div>

    <br>
    <?php if($uno == false): ?>
    <div class="col-md-12 text-center">
        <div class="form-group text">
            <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-success'])); ?>

        </div>
    </div>
    <?php else: ?>
    <div class="btn btn-lg btn-danger disabled"> No se puede ingresar </div>
    <?php endif; ?>
    <br>
    <br>