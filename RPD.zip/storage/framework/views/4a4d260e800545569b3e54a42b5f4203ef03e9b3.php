<div class="card text-left">
    <div class="card-body">
        <div class="row">
            <div class="form-group col-md-4">
                <?php echo e(Form::label('tarja_reproceso', 'Numero de tarja')); ?>

                <?php echo e(Form::text('tarja_reproceso','Re-proceso '.$lastid, ['class' => 'form-control', 'readonly'])); ?>

            </div>
            <div class="form-group col-md-4">
                <?php echo e(Form::label('wash', 'Lavado')); ?>

                <?php echo e(Form::select('wash', array('1' => 'Si', '2' => 'No'), 
							null ,['class' => 'form-control','required' ,'placeholder'=>'¿Esta Lavado?'])); ?>

            </div>
        </div>

        <div class="col-md-12">

            <h3 class="text-center">Listado</h3>



            </br>
            </br>
            </br>

          

            <div class="form-group"> 

                <table class="table table-bordered">
                    <thead>
                        <tr class="">
                            <th>N°</th>
                            <th>Especie</th>
                            <th>Variedad</th>
                            <th>Calidad</th>
                            <th>Condición</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                   
                        <?php $__empty_1 = true; $__currentLoopData = $reprocessPending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>  
                            <td><?php echo e($pending->tarja_reproceso); ?></td>
                            <td><?php echo e($pending->fruit->specie); ?></td>
                            <td><?php echo e($pending->varieties->variety); ?></td>
                            <td><?php echo e($pending->quality->name); ?></td>
                            <td><?php echo e($pending->status->name); ?></td>
                            
                            <td> <a class="btn btn-sm btn-primary" href=" 
                            <?php echo e(Route('subreprocess.create', [$pending->id, $identificador='s'])); ?> "> Reanudar </a> </td>
                            <?php
                            $uno = false;
                            ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h4> Sin Registros </h4>
                        <?php
                        $uno = true;
                        ?>
                        <?php endif; ?>
                    </tbody>
					<div class="float-left">
                    <?php echo e($reprocessPending->render()); ?>

                </div>
                </table>   

            </br>
            </br>
            </br>

            <div class=" col-md-4">
            <p>Filtrar:</p>  
            <input class="form-control" id="myInput" type="text" placeholder="Buscar..">
            <br>
            </div>

            <div class="form-group"> 
                <h4 class="text-center">Lote</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr class="">
                                    <th></th>
                                    <th>Tarja</th>
                                    <th>Calidad</th>
                                    <th>Cantidad</th>
                                    <th>Formato</th>
                                    <th>Fruta - Variedad</th>
                        </tr>
                    </thead>
                    <tbody id="myTable3">

                                <?php $__empty_1 = true; $__currentLoopData = $subprocesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subprocess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" name="subprocess[]" value="<?php echo e($subprocess->id); ?>">
                                    </td>
                                    <td><?php echo e($subprocess->tarja); ?></td>
                                    <td><?php echo e($subprocess->quality->name); ?></td>
                                    <td class="quantity"><?php echo e($subprocess->quantity); ?></td>
                                    <td><?php echo e($subprocess->format->name); ?></td>
                                    <td><?php echo e($subprocess->fruit->specie); ?> - <?php echo e($subprocess->varieties->variety); ?> </td>



                                    <?php
                                    $uno = false;
                                    ?>

                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <h4> Sin Registros </h4>

                                <?php
                                $uno = true;
                                ?>

                                <?php endif; ?>


                            </tbody>
                            <?php echo e($subprocesses->render()); ?>


					<div class="float-left">
                
                </div>
                </table>
                
                </br>
                </br>
                </br>
                </br>
        
                <div>
                    <h4 class="text-center">Palet</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr class="">
                        <th></th>
                                    <th>Tarja</th>
                                    <th>Calidad</th>
                                    <th>Cantidad</th>
                                    <th>Formato</th>
                                    <th>Fruta - Variedad</th>
                        </tr>
                    </thead>

                    </br>
                    </br>

                        <tbody id="myTable5">

                                    <?php $__empty_1 = true; $__currentLoopData = $lotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td> 
                                            <input type="checkbox" name="lotes[]" value="<?php echo e($lote->id); ?>"> 
                                        </td>

                                        <td><?php echo e($lote->numero_lote); ?></td>
                                        <td><?php echo e($lote->quality->name); ?></td>
                                        <td><?php echo e($lote->quantity); ?></td>
                                        <td><?php echo e($lote->format->name); ?></td>
                                        <td><?php echo e($lote->fruit->specie); ?> - <?php echo e($lote->varieties->variety); ?></td>


                                        <?php
                                        $uno = false;
                                        ?>

                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <h4> Sin Registros </h4>

                                    <?php
                                    $uno = true;
                                    ?>

                                    <?php endif; ?>


                                </tbody>
                                <?php echo e($lotes->render()); ?>

                        
                    </tbody>
					<div class="float-left">
                    
                </table>
                </div>
                
            </div>
            <script>
                $(document).ready(function(){
                    $("#myInput").on("keyup", function() {
                        var value = $(this).val().toLowerCase();
                        $("#myTable tr").filter(function() {
                            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                            });
                    });
                });
            </script>
        </div>
    </div>

    <br>

    
    <div class="col-md-12 text-center">
        <div class="form-group text">
            <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-success'])); ?>

        </div>
    </div>
    

   
    <br>
    <br>