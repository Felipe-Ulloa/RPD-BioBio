<div class="form-group">
	<?php echo e(Form::label('name', 'Nombre del Tipo de Transporte:')); ?>

	<?php echo e(Form::text('name', null, ['class' => 'form-control '])); ?>

</div>


<div class="form-group">
	<?php echo e(Form::submit('Guardar', ['class' => 'btn btn-success'])); ?>

</div>

